import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import Spirado from './Spirado'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Spirado />
  </React.StrictMode>
)
