import React from "react";
import { Card, CardContent } from "./components/ui/card";
import { Button } from "./components/ui/button";

export default function Spirado() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow-md p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <img src="/spirado-logo.png" alt="Spirado Logo" className="w-10 h-10" />
          <h1 className="text-xl font-bold">Spirado</h1>
        </div>
        <nav className="space-x-4">
          <a href="#home" className="hover:text-blue-600">Home</a>
          <a href="#services" className="hover:text-blue-600">Services</a>
          <a href="#contact" className="hover:text-blue-600">Contact</a>
        </nav>
      </header>

      <section id="home" className="text-center py-16 bg-gradient-to-br from-blue-100 to-white">
        <h2 className="text-4xl font-semibold mb-4">Expert Content. Powerful Ebooks.</h2>
        <p className="text-lg max-w-xl mx-auto mb-6">
          Spirado helps you create impactful ebooks, written content, and professional PDF materials tailored to your needs.
        </p>
        <Button className="text-white bg-blue-600 hover:bg-blue-700">Get Started</Button>
      </section>

      <section id="services" className="py-12 px-4 max-w-6xl mx-auto">
        <h3 className="text-3xl font-semibold mb-8 text-center">Our Services</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">Ebook Advising</h4>
              <p className="mb-4">We guide you in planning, structuring, and polishing your ebook for maximum impact.</p>
              <Button variant="outline">Learn More</Button>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">Written Content</h4>
              <p className="mb-4">Professional articles, guides, and custom content to elevate your brand’s voice.</p>
              <Button variant="outline">Learn More</Button>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <h4 className="text-xl font-bold mb-2">PDF Creation</h4>
              <p className="mb-4">Clean, branded PDFs designed to communicate your ideas clearly and attractively.</p>
              <Button variant="outline">Learn More</Button>
            </CardContent>
          </Card>
        </div>
      </section>

      <footer className="bg-gray-100 text-center py-6 text-sm text-gray-500">
        © 2025 Spirado. All rights reserved.
      </footer>
    </div>
  );
}
